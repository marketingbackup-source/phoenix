import { getPosts } from "@/services/cms/posts/get-posts";
import { getCategoryId } from "@/services/cms/categories/get-category-id";

import PostGrid from "@/components/posts/PostGrid";
import Pagination from "@/components/posts/Pagination";
import { pressReleaseMetadata } from "@/components/Meta/PressRelease/pressReleaseMetadata";
import PressReleaseSchema from "@/components/Meta/PressRelease/PressReleaseSchema";

export const metadata = pressReleaseMetadata;

export const dynamic = "force-dynamic";
export const revalidate = 0;


export default async function PressReleasePage({
  searchParams,
}) {

  const categoryId =
    await getCategoryId("press-release");


  const resolvedSearchParams =
    await searchParams;


  const pageParam =
    resolvedSearchParams?.page;


  const currentPage =
    Math.max(
      1,
      parseInt(pageParam, 10) || 1
    );


  const {
    posts,
    totalPosts,
    totalPages,
    perPage,
  } = await getPosts({

    category: categoryId,

    page: currentPage,

    perPage: 12,

    embed: true,

  });


  return (

    <>
     <PressReleaseSchema posts={posts} />
    <section
      className="
      py-80-30
      bg-white
      "
    >

      <div className="container-main">


        <div
          className="
          text-center
          mt-18 lg:mt-12
          !mb-12
          "
        >

          <h1
            className="
            fs-52-32
            uppercase
            text-black
            "
          >

            Press{" "}

            <span className="text-[var(--color-red-1)]">
              Release
            </span>

          </h1>


        </div>


        <PostGrid
          posts={posts}
          basePath="/press-release"
        />


        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          basePath="/press-release"
        />


      </div>


    </section>
    </>

  );

}