"use client";

import Image from "next/image";
import { ArrowRight } from "lucide-react";

import BaseButton from "@/components/UI/BaseButton";

export default function ApprovalBanner() {
  return (
    <section
      className="
      relative
      py-80-40
      min-h-[100vh]
      overflow-hidden
      flex
      flex-col
      items-center
      justify-center
      "
    >

      {/* Background Video */}

      <video
        className="
        absolute
        inset-0
        w-full
        h-full
        object-cover
        "
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
      >
        <source
          src="https://cms.phoenixbusinessadvisory.com/wp-content/uploads/2026/09/background-katko.mp4"
          type="video/mp4"
        />
      </video>


      {/* Content */}

      <div className="container-main relative z-10">

        <div
          className="
          flex
          flex-col-reverse
          lg:flex-row
          items-center
          gap-60-20
          "
        >

          {/* Left Content */}

          <div
            className="
            w-full
            lg:w-6/12
            "
            data-reveal
          >

            <p
              className="
              uppercase
              tracking-[2px]
              text-[var(--color-red-1)]
              !mb-5
              "
            >
              Our Approvals
            </p>


            <h1
              className="
              fs-52-32
              uppercase
              text-black
              !mb-8
              "
            >
              Proven Success Through{" "}
              <span className="text-[var(--color-red-1)]">
                Immigration Approvals
              </span>
            </h1>


            <p
              className="
              text-gray-500
              fs-20-16
              leading-[1.7]
              max-w-xl
              !mb-8
              "
            >
              Phoenix Business Advisory has successfully assisted clients in
              achieving L-1 Visa approvals, immigration petition approvals,
              and Green Card success through strategic planning, detailed
              documentation, and expert guidance throughout the process.
            </p>


            <BaseButton
              title="View Success Stories"
              link
              toLink="/testimonials"
              style="primary w-fit"
            >
              <ArrowRight size={20} />
            </BaseButton>

          </div>


          {/* Right Image */}

          <div
            className="
            w-full
            lg:w-6/12
            flex-center
            mt-15 lg:mt-0
            "
          >

            <div
              className="
              relative
              w-full
              max-w-[600px]
              "
            >

              <Image
                src="https://cms.phoenixbusinessadvisory.com/wp-content/uploads/2026/09/Approvals.png"
                alt="Phoenix Business Advisory Approvals"
                width={700}
                height={700}
                className="
                w-full
                object-contain
                max-w-[450px]
                mix-blend-multiply
                "
                priority
                data-reveal="right"
              />

            </div>

          </div>

        </div>

      </div>

    </section>
  );
}