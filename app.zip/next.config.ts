import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
  remotePatterns: [
    {
      protocol: "https",
      hostname: "cms.phoenixbusinessadvisory.com",
      pathname: "/**",
    },
    {
      protocol: "https",
      hostname: "cdn.prod.website-files.com",
      pathname: "/**",
    },
  ],
},
};

export default nextConfig;
